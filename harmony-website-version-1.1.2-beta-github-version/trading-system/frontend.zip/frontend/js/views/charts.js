export function render() {
    return `<h1>📊 Chart Works</h1>`;
}