export const router = {
    init() {
        window.addEventListener("hashchange", () => this.handleRoute());
        this.handleRoute();
    },

    getRoute() {
        return window.location.hash.replace("#", "") || "home";
    },

    async handleRoute() {
        const route = this.getRoute();
        await this.loadView(route);
    },

    async loadView(viewName) {
        const content = document.getElementById("content");

        try {
            const module = await import(`./views/${viewName}.js`);

            console.log(module);

            content.innerHTML = module.render();

            if (module.init) {
                module.init();
            }

        } catch (e) {
            console.error(e);

            content.innerHTML = `
                <h2>Page failed to load</h2>
                <pre>${e.message}</pre>
            `;
        }
    }
};